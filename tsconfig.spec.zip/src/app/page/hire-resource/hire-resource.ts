import { Component } from '@angular/core';
import { HireHeroSection } from '../../component/hire-resource/hire-hero-section/hire-hero-section';

@Component({
  selector: 'app-hire-resource',
  imports: [HireHeroSection],
  templateUrl: './hire-resource.html',
  styleUrl: './hire-resource.css',
})
export class HireResource {

}
