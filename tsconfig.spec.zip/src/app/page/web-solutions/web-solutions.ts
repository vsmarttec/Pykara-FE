import { Component } from '@angular/core';
import { HeroSectionWeb } from '../../component/web-solutions/hero-section-web/hero-section-web';

@Component({
  selector: 'app-web-solutions',
  imports: [HeroSectionWeb],
  templateUrl: './web-solutions.html',
  styleUrl: './web-solutions.css',
})
export class WebSolutions {

}
