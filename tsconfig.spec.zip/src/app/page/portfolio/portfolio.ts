import { Component } from '@angular/core';
import { Project } from '../../component/Portfolio/project/project';

@Component({
  selector: 'app-portfolio',
  imports: [Project],
  templateUrl: './portfolio.html',
  styleUrl: './portfolio.css',
})
export class Portfolio {

}
