import { Component } from '@angular/core';
import { ContactHeroSection } from '../../component/contactus/contact-hero-section/contact-hero-section';

@Component({
  selector: 'app-contact-us',
  imports: [ContactHeroSection],
  templateUrl: './contact-us.html',
  styleUrl: './contact-us.css',
})
export class ContactUs {

}
